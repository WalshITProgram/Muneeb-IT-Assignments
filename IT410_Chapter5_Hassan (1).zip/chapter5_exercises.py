"""
Chapter 5 - Try It Yourself Exercises
Problems 5-1 through 5-6
"""

# ---------------------------------------------------------
# Problem 5-1: Conditional Tests
# Create six conditional tests - three True, three False.
# ---------------------------------------------------------
print("--- Problem 5-1 ---")

# I predict the expression below will evaluate to True
color = "blue"
print(color == "blue")

# I predict the expression below will evaluate to False
color = "red"
print(color == "blue")

# I predict the expression below will evaluate to True
number = 10
print(number > 5)

# I predict the expression below will evaluate to False
number = 3
print(number > 5)

# I predict the expression below will evaluate to True
fruit = "apple"
print(fruit in ["apple", "banana", "cherry"])

# I predict the expression below will evaluate to False
fruit = "grape"
print(fruit in ["apple", "banana", "cherry"])


# ---------------------------------------------------------
# Problem 5-2: Odd or Even
# Check whether a number is odd using an if test.
# ---------------------------------------------------------
print("\n--- Problem 5-2 ---")

# This number should make the if test evaluate to True (it is odd)
number = 7
if number % 2 != 0:
    print(f"{number} is odd.")

# This number should make the if test evaluate to False (it is even)
number = 8
if number % 2 != 0:
    print(f"{number} is odd.")


# ---------------------------------------------------------
# Problem 5-3: If-Else Odd or Even
# Modify 5-2 to use an if-else block.
# ---------------------------------------------------------
print("\n--- Problem 5-3 ---")

number = 7
if number % 2 != 0:
    print(f"{number} is odd.")
else:
    number += 1
    print(f"The number is now {number}.")

number = 8
if number % 2 != 0:
    print(f"{number} is odd.")
else:
    number += 1
    print(f"The number is now {number}.")


# ---------------------------------------------------------
# Problem 5-4: Favorite Fruits
# If-elif-else chain checking the length of a list.
# ---------------------------------------------------------
print("\n--- Problem 5-4 ---")

favorite_fruits = ["apple", "banana", "mango"]

if len(favorite_fruits) == 2:
    print("You like two fruits.")
elif len(favorite_fruits) == 3:
    print("You like three fruits.")
elif len(favorite_fruits) == 4:
    print("You like four fruits.")
elif len(favorite_fruits) >= 5:
    print("You like several fruits.")


# ---------------------------------------------------------
# Problem 5-5: Numbers 1-55
# Check if two chosen numbers are in a list of numbers 1-55.
# ---------------------------------------------------------
print("\n--- Problem 5-5 ---")

numbers = list(range(1, 56))

first_number = 23
second_number = 99

if first_number in numbers:
    print(f"{first_number} was found in the list.")
else:
    print(f"{first_number} was not found in the list.")

if second_number in numbers:
    print(f"{second_number} was found in the list.")
else:
    print(f"{second_number} was not found in the list.")


# ---------------------------------------------------------
# Problem 5-6: Favorite Stores and Sales
# Loop through favorite stores and check against a list of
# stores currently running sales.
# ---------------------------------------------------------
print("\n--- Problem 5-6 ---")

favorite_stores = ["Target", "Best Buy", "Nike", "GameStop"]
stores_on_sale = ["Nike", "Old Navy", "Best Buy"]

for store in favorite_stores:
    if store in stores_on_sale:
        print(f"Good news! {store} is having a sale. You should check it out!")
    else:
        print(f"{store} isn't currently running a sale.")
