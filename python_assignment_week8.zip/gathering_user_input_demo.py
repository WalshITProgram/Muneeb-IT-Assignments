# Gathering User Input Demonstration - Demo Code (validating an area code)

area_code = input("Please enter your area code: ")

# Make sure the user actually typed something
if area_code:
    try:
        # int() raises an error if the input isn't made of digits
        int(area_code)
        # An area code should be exactly 3 digits long
        if len(area_code) == 3:
            print("Your area code is: " + area_code)
        else:
            print("Your inputted area code isn't long enough")
    except:
        print("You did not provide a valid area code")
else:
    print("You did not enter an area code.")
