# Chapter 7 - Try It Yourself Exercises (User Input and While Loops)

# ---------------------------------------------------------
# Problem 7-1: Favorite restaurant
# ---------------------------------------------------------
print("--- Problem 7-1 ---")
restaurant = input("What is your favorite restaurant? ")
print("Let me help you find the closest " + restaurant + ".")

# ---------------------------------------------------------
# Problem 7-2: Multiply two numbers
# ---------------------------------------------------------
print("\n--- Problem 7-2 ---")
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
print("The result of " + str(num1) + " x " + str(num2) +
      " is " + str(num1 * num2))

# ---------------------------------------------------------
# Problem 7-3: While loop collecting dinner items
# ---------------------------------------------------------
print("\n--- Problem 7-3 ---")
dinner_items = []
while True:
    item = input("What are you having for dinner? (type 'quit' to finish) ")
    if item.lower() == 'quit':      # way for the user to break the loop
        break
    dinner_items.append(item)

print("\nYour dinner items:")
for item in dinner_items:
    print("- " + item)

# ---------------------------------------------------------
# Problem 7-4: Carnival rides
# ---------------------------------------------------------
print("\n--- Problem 7-4 ---")
while True:
    ride = input("Which ride would you like to go on? "
                 "(Ferris Wheel, Tilt-a-Whirl, Pirate Ship, or 'quit') ").lower()
    if ride == 'quit':              # way for the user to break the loop
        break
    elif ride == 'ferris wheel':
        print("That will be $2, please.")
    elif ride == 'tilt-a-whirl':
        print("That will be $3, please.")
    elif ride == 'pirate ship':
        print("That will be $3.50, please.")
    else:
        print("Sorry, that ride was not found.")

# ---------------------------------------------------------
# Problem 7-5: Remove all instances of a repeated item
# ---------------------------------------------------------
print("\n--- Problem 7-5 ---")
groceries = ['milk', 'eggs', 'bread', 'chips', 'apples', 'chips', 'chips']
print("Original list:", groceries)

# I decided not to buy chips, so remove every instance using a while loop
while 'chips' in groceries:
    groceries.remove('chips')

print("Updated list:", groceries)
