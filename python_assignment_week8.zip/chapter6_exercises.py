# Chapter 6 - Try It Yourself Exercises (Dictionaries)

# ---------------------------------------------------------
# Problem 6-1: Dictionary about a favorite movie
# ---------------------------------------------------------
movie = {
    'title': 'The Matrix',
    'rating': 'R',
    'director': 'The Wachowskis',
    'year': 1999,
    'genre': 'Science Fiction',        # extra piece of info #1
    'runtime_minutes': 136,            # extra piece of info #2
}
print("--- Problem 6-1 ---")
print(movie)

# ---------------------------------------------------------
# Problem 6-2: Product dictionary, raise price by 30%
# ---------------------------------------------------------
product = {
    'item_number': 1001,
    'product_name': 'Wireless Mouse',
    'price': 20.00,
}

# Increase the current price by 30% and store it back in the dictionary
product['price'] = product['price'] * 1.30

print("\n--- Problem 6-2 ---")
print("The price of the " + product['product_name'] +
      " has been increased by 30%. The new price is $" +
      str(round(product['price'], 2)) + ".")

# ---------------------------------------------------------
# Problem 6-3: Loop through keys and values of the 6-1 dictionary
# ---------------------------------------------------------
print("\n--- Problem 6-3 ---")
for key, value in movie.items():
    print(key.title() + ": " + str(value))

# ---------------------------------------------------------
# Problem 6-4: List of dictionaries (word and definition)
# ---------------------------------------------------------
words = [
    {'word': 'variable', 'definition': 'A name that stores a value in a program.'},
    {'word': 'loop', 'definition': 'A structure that repeats a block of code.'},
    {'word': 'dictionary', 'definition': 'A collection of key-value pairs.'},
    {'word': 'function', 'definition': 'A reusable block of code that performs a task.'},
]

print("\n--- Problem 6-4 ---")
for item in words:
    print(item['word'].title() + ": " + item['definition'])

# ---------------------------------------------------------
# Problem 6-5: Add a list of actors to the 6-1 dictionary
# ---------------------------------------------------------
movie['actors'] = ['Keanu Reeves', 'Laurence Fishburne',
                   'Carrie-Anne Moss', 'Hugo Weaving']

print("\n--- Problem 6-5 ---")
for actor in movie['actors']:
    print(actor)
