# Working with Dictionaries - Demo Code (pizza preferences)

# A list of dictionaries. Each dictionary is one person's pizza preferences.
# Note that 'toppings' is a string for some people and a list for others.
pizza_prefs = [
    {'name': 'sandeep', 'toppings': 'mushrooms', 'pizza_type': 'round'},
    {'name': 'kylie', 'toppings': ['ham', 'pineapple'], 'pizza_type': 'square'},
    {'name': 'lisa', 'toppings': ['mushrooms', 'pepperoni'], 'pizza_type': 'square'},
    {'name': 'dan', 'toppings': ['bacon', 'sausage', 'pepperoni'], 'pizza_type': 'square'},
]

# Access a value in the first dictionary
print(pizza_prefs[0]['toppings'])

# Loop through the list and check each person's name
for person in pizza_prefs:
    if person['name'] == 'sandeep':
        print("This is sandeep")
    else:
        print("This is not sandeep")

# Find everyone who likes mushrooms.
# 'toppings' can be a string OR a list, so check the type first.
for person in pizza_prefs:
    if type(person['toppings']) is str:
        if person['toppings'] == "mushrooms":
            print(person['name'] + " likes mushrooms")
    elif type(person['toppings']) is list:
        if "mushrooms" in person['toppings']:
            print(person['name'] + " likes mushrooms")

# Print the whole list before changing it
print(pizza_prefs)

# Remove everyone who likes mushrooms from the list
for person in pizza_prefs:
    mushrooms_found = False

    if type(person['toppings']) is str:
        if(person['toppings']) == "mushrooms":
            mushrooms_found = True
    elif type(person['toppings']) is list:
        if("mushrooms" in person['toppings']):
            mushrooms_found = True

    if mushrooms_found:
        pizza_prefs.remove(person)

print(pizza_prefs)
